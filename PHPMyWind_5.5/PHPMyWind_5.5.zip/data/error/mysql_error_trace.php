<?php exit(); ?> Time: 2018-05-24 16:10:52. || Page: /admin/diyfield_save.php || IP: 0.0.0.0 || Error: Duplicate column name 'title' Error sql: ALTER TABLE `pmw_tupian` ADD `title` mediumtext NOT NULL
<?php exit(); ?> Time: 2018-05-24 16:16:33. || Page: /admin/diyfield_save.php || IP: 0.0.0.0 || Error: Duplicate column name 'title' Error sql: ALTER TABLE `pmw_tupian` ADD `title` text NOT NULL
